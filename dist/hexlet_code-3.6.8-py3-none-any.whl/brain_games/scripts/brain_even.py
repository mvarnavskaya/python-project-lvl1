#!/usr/bin/env python
from brain_games import parity


def greet():
    print('Welcome to the Brain Games!')
    parity.is_parity()


def main():
    greet()


if __name__ == '__main__':
    greet()
