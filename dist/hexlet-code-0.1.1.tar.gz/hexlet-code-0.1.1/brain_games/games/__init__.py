from brain_games.games import even, calc, gsd, progress, prime


__all__ = ('even', 'calc', 'gsd', 'progress', 'prime')
